package com.chavez.appfirebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
